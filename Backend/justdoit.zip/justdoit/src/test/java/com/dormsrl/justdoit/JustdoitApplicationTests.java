package com.dormsrl.justdoit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JustdoitApplicationTests {

	@Test
	void contextLoads() {
	}

}
